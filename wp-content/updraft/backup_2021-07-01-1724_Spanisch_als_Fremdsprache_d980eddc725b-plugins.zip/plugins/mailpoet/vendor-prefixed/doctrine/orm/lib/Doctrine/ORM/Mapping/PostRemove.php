<?php
 namespace MailPoetVendor\Doctrine\ORM\Mapping; if (!defined('ABSPATH')) exit; final class PostRemove implements \MailPoetVendor\Doctrine\ORM\Mapping\Annotation { } 