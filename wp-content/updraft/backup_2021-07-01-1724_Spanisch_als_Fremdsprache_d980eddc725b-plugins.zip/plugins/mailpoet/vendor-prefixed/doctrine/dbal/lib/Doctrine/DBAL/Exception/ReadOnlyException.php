<?php
 namespace MailPoetVendor\Doctrine\DBAL\Exception; if (!defined('ABSPATH')) exit; class ReadOnlyException extends \MailPoetVendor\Doctrine\DBAL\Exception\ServerException { } 