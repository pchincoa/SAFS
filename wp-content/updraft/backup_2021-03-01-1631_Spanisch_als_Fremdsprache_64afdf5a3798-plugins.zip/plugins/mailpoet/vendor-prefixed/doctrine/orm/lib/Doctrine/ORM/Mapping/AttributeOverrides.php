<?php
 namespace MailPoetVendor\Doctrine\ORM\Mapping; if (!defined('ABSPATH')) exit; final class AttributeOverrides implements \MailPoetVendor\Doctrine\ORM\Mapping\Annotation { public $value; } 