<?php
 namespace MailPoetVendor\Doctrine\ORM\Mapping; if (!defined('ABSPATH')) exit; final class CustomIdGenerator implements \MailPoetVendor\Doctrine\ORM\Mapping\Annotation { public $class; } 