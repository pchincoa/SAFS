<?php
 if (!defined('ABSPATH')) exit; return [ 'en' => [ 'isoName' => 'English', 'nativeName' => 'English', ], ];