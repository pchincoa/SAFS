<?php
 namespace MailPoetVendor\Doctrine\ORM\Mapping; if (!defined('ABSPATH')) exit; class ClassMetadata extends \MailPoetVendor\Doctrine\ORM\Mapping\ClassMetadataInfo { } 