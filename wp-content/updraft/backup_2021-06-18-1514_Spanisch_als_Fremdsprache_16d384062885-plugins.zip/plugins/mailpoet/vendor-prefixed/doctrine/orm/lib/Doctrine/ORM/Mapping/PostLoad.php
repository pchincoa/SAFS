<?php
 namespace MailPoetVendor\Doctrine\ORM\Mapping; if (!defined('ABSPATH')) exit; final class PostLoad implements \MailPoetVendor\Doctrine\ORM\Mapping\Annotation { } 