<?php
 namespace MailPoetVendor\Doctrine\ORM\Mapping; if (!defined('ABSPATH')) exit; final class DiscriminatorMap implements \MailPoetVendor\Doctrine\ORM\Mapping\Annotation { public $value; } 