<?php
 namespace MailPoetVendor\Doctrine\ORM\Mapping; if (!defined('ABSPATH')) exit; final class PostPersist implements \MailPoetVendor\Doctrine\ORM\Mapping\Annotation { } 