<?php
 namespace MailPoetVendor\Doctrine\ORM\Mapping; if (!defined('ABSPATH')) exit; final class JoinColumns implements \MailPoetVendor\Doctrine\ORM\Mapping\Annotation { public $value; } 