<?php
 namespace MailPoetVendor\Doctrine\ORM\Cache; if (!defined('ABSPATH')) exit; class LockException extends \MailPoetVendor\Doctrine\ORM\Cache\CacheException { } 