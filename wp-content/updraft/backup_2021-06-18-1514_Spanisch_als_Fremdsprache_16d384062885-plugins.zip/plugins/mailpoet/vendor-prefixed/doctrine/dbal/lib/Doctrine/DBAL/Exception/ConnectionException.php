<?php
 namespace MailPoetVendor\Doctrine\DBAL\Exception; if (!defined('ABSPATH')) exit; class ConnectionException extends \MailPoetVendor\Doctrine\DBAL\Exception\DriverException { } 