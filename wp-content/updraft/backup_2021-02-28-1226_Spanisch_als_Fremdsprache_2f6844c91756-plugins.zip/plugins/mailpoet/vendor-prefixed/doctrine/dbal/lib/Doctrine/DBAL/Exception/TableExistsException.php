<?php
 namespace MailPoetVendor\Doctrine\DBAL\Exception; if (!defined('ABSPATH')) exit; class TableExistsException extends \MailPoetVendor\Doctrine\DBAL\Exception\DatabaseObjectExistsException { } 