<?php
 namespace MailPoetVendor\Doctrine\Common; if (!defined('ABSPATH')) exit; class CommonException extends \Exception { } 